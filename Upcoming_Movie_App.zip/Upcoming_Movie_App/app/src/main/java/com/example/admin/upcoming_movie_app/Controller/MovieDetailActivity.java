package com.example.admin.upcoming_movie_app.Controller;

import android.support.v4.app.FragmentTransaction;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.example.admin.upcoming_movie_app.AdapterClass.ViewPageAdapter;
import com.example.admin.upcoming_movie_app.ConfigFile.Config;
import com.example.admin.upcoming_movie_app.Model.MovieImageList;
import com.example.admin.upcoming_movie_app.Model.GlobalClass;
import com.example.admin.upcoming_movie_app.R;
import com.google.gson.Gson;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MovieDetailActivity extends AppCompatActivity  {
     ViewPager viewPager;
     ViewPageAdapter viewPageAdapter;
     PagerAdapter pagerAdapter;
     LinearLayout ll_dots;
    private TextView[] dots;
    int dotscount;
    MovieDetailActivity movieDetailActivity;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_detail);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        int movieid = getIntent().getExtras().getInt("movieid");
        String moviename = getIntent().getExtras().getString("moviename");
        GlobalClass globalclass = (GlobalClass) getApplicationContext();
        globalclass.setMovieid(movieid);
        String imageurl = Config.movieimageurl+globalclass.getMovieid()+"/images"+Config.api_key;
        viewPager = (ViewPager) findViewById(R.id.view_pager);
        ll_dots = (LinearLayout) findViewById(R.id.ll_dots);
        Log.d("MovieDetailActivity", imageurl);
        getSupportActionBar().setTitle(moviename);

        viewPager.setOnPageChangeListener(new OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                addBottomDots(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        try {
            ImageData(imageurl);
        } catch (IOException e1) {
            e1.printStackTrace();
        }


        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        Bundle bundle = new Bundle();
        bundle.putString("id", String.valueOf(movieid));
        DescriptionFragment descriptionFragment = new DescriptionFragment();
        Log.d("MovieDetailActivity",  String.valueOf(movieid));
        descriptionFragment.setArguments(bundle);
        ft.replace(R.id.your_placeholder,descriptionFragment);
        ft.commit();


    }


    private void addBottomDots(int currentPage) {
        dots = new TextView[dotscount];
        ll_dots.removeAllViews();
        for(int i = 0 ; i<dots.length;i++){
            dots[i] = new TextView(this);
            dots[i].setText(Html.fromHtml("&#8226;"));
            dots[i].setTextSize(35);
            dots[i].setTextColor(Color.parseColor("#000000"));
            ll_dots.addView(dots[i]);


        }
        if (dots.length > 0)
            dots[currentPage].setTextColor(Color.parseColor("#FFFFFF"));

    }

    private void ImageData(String imageurl) throws IOException{

        OkHttpClient okHttpClient = new OkHttpClient();
        Request request = new Request.Builder()
                .url(imageurl)
                .build();

        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d("MovieImageClass ", "Fails network Call");

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                String json = response.body().string();
                Log.d("errr1",json);
                MovieImageList movieImageList = new MovieImageList();

                Gson gson = new Gson();
                movieImageList = gson.fromJson(json,MovieImageList.class);
                GlobalClass globalclass = (GlobalClass) getApplicationContext();
                globalclass.setMovieImageList(movieImageList);
                viewPageAdapter = new ViewPageAdapter(getApplicationContext(),globalclass.getMovieImageList().getBackdrops());


                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {

                       viewPager.setAdapter(viewPageAdapter);
                       dotscount = viewPageAdapter.getCount();
                       viewPageAdapter.notifyDataSetChanged();
                        addBottomDots(0);
                    }
                });

                Log.d("12ImageData", json);

            }
        });


    }


}
