package com.example.admin.upcoming_movie_app.Model;

import android.app.Application;

/**
 * Created by Admin on 24-04-2017.
 */
public class GlobalClass extends Application {
    public MovieList movieList;

    public MovieImageList getMovieImageList() {
        return movieImageList;
    }

    public void setMovieImageList(MovieImageList movieImageList) {
        this.movieImageList = movieImageList;
    }

    public MovieImageList movieImageList;

    public int getMovieid() {
        return movieid;
    }

    public void setMovieid(int movieid) {
        this.movieid = movieid;
    }

    public int movieid;
    public String getJsonImage() {
        return jsonImage;
    }

    public void setJsonImage(String jsonImage) {
        this.jsonImage = jsonImage;
    }

    public String jsonImage;

    public MovieList getMovieList() {
        return movieList;
    }

    public void setMovieList(MovieList movieList) {
        this.movieList = movieList;
    }


}
