package com.example.admin.upcoming_movie_app.AdapterClass;

import android.content.Context;
import android.os.Handler;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.admin.upcoming_movie_app.Model.Backdrop;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Admin on 26-04-2017.
 */
public class ViewPageAdapter extends PagerAdapter {
    Context context;
    List<Backdrop> backdrops;
    LayoutInflater mLayoutInflater;

    int iImageWidth;
    public ViewPageAdapter(Context applicationContext, List<Backdrop> backdrops){
       this.context = applicationContext;
       this.backdrops = backdrops;
        mLayoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        notifyDataSetChanged();
    }


    @Override
    public View instantiateItem(final ViewGroup container, int position) {

        final String url = backdrops.get(position).getFilePath();
        Log.d("viewpager", url);
        final ImageView imgview =new ImageView(context);
        imgview.setPadding(0, 0, 0, 0);
        final Handler mainHandler = new Handler(context.getMainLooper());
        Runnable myRunnable = new Runnable() {
            @Override
            public void run() {
                iImageWidth = context.getResources().getDisplayMetrics().widthPixels;
                Picasso.with(context)
                        .load(url)
                        .resize(900, 400)
                        .into(imgview);

                ((ViewPager) container).addView(imgview, 0);
            } // This is your code
        };
        mainHandler.post(myRunnable);


        return imgview;
    }



    @Override
    public int getCount() {
        if(backdrops.size()<= 5) {
            return backdrops.size();
        }
        else {
            return 5;
        }
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == ((ImageView) object);
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        ((ViewPager) container).removeView((ImageView) object);
    }
}
