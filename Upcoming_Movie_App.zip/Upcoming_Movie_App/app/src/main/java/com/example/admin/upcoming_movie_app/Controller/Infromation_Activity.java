package com.example.admin.upcoming_movie_app.Controller;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.admin.upcoming_movie_app.R;

public class Infromation_Activity extends AppCompatActivity {
TextView txtname,txtmob,txtquali,txtexp,txtemail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_infromation_);

        txtname =(TextView) findViewById(R.id.Name);
        txtmob = (TextView) findViewById(R.id.Mobile_No);
        txtquali = (TextView) findViewById(R.id.Qualificaton);
        txtexp = (TextView) findViewById(R.id.Experience);
        txtemail = (TextView) findViewById(R.id.Email);

        txtname.setText("Name:-"+"Uday Vijay Surse");
        txtmob.setText("Contact:-"+"9637747303");
        txtquali.setText("Qualification:-"+"B.E.Computer");
        txtexp.setText("Experience:-"+"2 year 2 Months"  +" , "+ "Relative Expereince:-1 year");
        txtemail.setText("Email:-"+"uvsurse@gmail.com");


    }
}
