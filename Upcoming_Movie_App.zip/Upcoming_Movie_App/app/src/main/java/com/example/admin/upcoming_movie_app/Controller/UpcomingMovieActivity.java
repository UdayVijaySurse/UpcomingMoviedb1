package com.example.admin.upcoming_movie_app.Controller;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.example.admin.upcoming_movie_app.AdapterClass.RecyclerAdapterClass;
import com.example.admin.upcoming_movie_app.Animation.SimpleDividerItemDecoration;
import com.example.admin.upcoming_movie_app.ConfigFile.Config;
import com.example.admin.upcoming_movie_app.Model.GlobalClass;
import com.example.admin.upcoming_movie_app.Model.MovieList;
import com.example.admin.upcoming_movie_app.R;
import com.google.gson.Gson;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class UpcomingMovieActivity extends AppCompatActivity {
    OkHttpClient okHttpClient = new OkHttpClient();
    MovieList movieList = new MovieList();
    private LinearLayoutManager layoutManager;
    RecyclerAdapterClass adapterClass;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upcoming_movie);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        assert toolbar != null;
        toolbar.setTitle("Upcoming Movie");
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        recyclerView.addItemDecoration(new SimpleDividerItemDecoration(this));
        layoutManager = new LinearLayoutManager(UpcomingMovieActivity.this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        layoutManager.scrollToPosition(0);
        recyclerView.setLayoutManager(layoutManager);


        try {
            movieList(Config.movielisturl);
        } catch(IOException e){
            e.printStackTrace();;
        }


    }

    private void movieList(String url) throws IOException{
        Request request = new Request.Builder()
                .url(url)
                .build();

        Call call = okHttpClient.newCall(request);

        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d("123","Network call fail");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                    String json = response.body().string();
                    Gson gson = new Gson();
                    movieList = gson.fromJson(json,MovieList.class);
                    Log.d("456", movieList.getPage().toString());

                    GlobalClass globalClass = (GlobalClass) getApplicationContext();
                    globalClass.setMovieList(movieList);
                    adapterClass = new RecyclerAdapterClass(UpcomingMovieActivity.this,globalClass.getMovieList().getResults());
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {

                        recyclerView.setAdapter(adapterClass);

                    }
                });

                    for(int i = 0 ;i<globalClass.getMovieList().getResults().size();i++) {
                        Log.d("111", globalClass.getMovieList().getResults().get(i).getTitle());
                    }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.action_bar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {


            case R.id.action_info:
                // User chose the "Informaton" action, mark the current item
                // as a information...
                Intent intent = new Intent(getApplicationContext(),Infromation_Activity.class);
                startActivity(intent);

                return true;

            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);
        }

    }
}
