package com.example.admin.upcoming_movie_app.Model;

/**
 * Created by Admin on 26-04-2017.
 */
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Backdrop {
    public static final String TMDB_IMAGE_PATH = "http://image.tmdb.org/t/p/w500";

    @SerializedName("file_path")
    @Expose
    private String filePath;



    public String getFilePath() {
        return TMDB_IMAGE_PATH+filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }


}

