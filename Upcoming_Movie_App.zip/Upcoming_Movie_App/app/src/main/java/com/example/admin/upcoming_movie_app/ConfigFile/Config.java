package com.example.admin.upcoming_movie_app.ConfigFile;

import android.app.Activity;
import android.content.Context;

/**
 * Created by Admin on 24-04-2017.
 */
public class Config {



    public static final String movielisturl = "https://api.themoviedb.org/3/movie/upcoming?api_key=b7cd3340a794e5a2f35e3abb820b497f";
    public static final String api_key = "?api_key=b7cd3340a794e5a2f35e3abb820b497f";
    public static final String movieimageurl = "https://api.themoviedb.org/3/movie/";
    public static final String moviedetailurl = "https://api.themoviedb.org/3/movie/";

}
