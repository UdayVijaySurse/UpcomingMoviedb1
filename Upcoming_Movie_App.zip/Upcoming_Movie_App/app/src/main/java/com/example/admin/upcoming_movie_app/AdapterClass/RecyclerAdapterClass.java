package com.example.admin.upcoming_movie_app.AdapterClass;

import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.admin.upcoming_movie_app.Controller.MovieDetailActivity;
import com.example.admin.upcoming_movie_app.R;
import com.example.admin.upcoming_movie_app.Model.Result;
import com.example.admin.upcoming_movie_app.Controller.UpcomingMovieActivity;
import com.example.admin.upcoming_movie_app.ViewHolderClass.RecyclerViewHolder;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Admin on 24-04-2017.
 */
public class RecyclerAdapterClass extends RecyclerView.Adapter<RecyclerViewHolder> {
       private ArrayList<Result> results;
       private UpcomingMovieActivity upcomingMovieActivity;



    public RecyclerAdapterClass(UpcomingMovieActivity upcomingMovieActivity, ArrayList<Result> results) {
       this.upcomingMovieActivity = upcomingMovieActivity;
       this.results = results;

    }

    @Override
    public RecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View layoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, null);
        RecyclerViewHolder rcv = new RecyclerViewHolder(layoutView);
        return rcv;
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolder holder, int position) {
        Log.d("udsay","inbindviewholder");
        holder.txtmoviename.setText("" + results.get(position).getTitle());
        holder.txtdate.setText("" + results.get(position).getReleaseDate());
        boolean adult = results.get(position).getAdult();
        if(adult){
            holder.txtadult.setText("A");
        }
        else{
            holder.txtadult.setText("U/A");
        }
        String url = results.get(position).getPosterPath();
        Picasso.with(upcomingMovieActivity)
                .load(url)
                .resize(400,400)
                .into(holder.imgposter);
        final int movieid = results.get(position).getId();
        final String moviename  =  results.get(position).getTitle();


        holder.txtmoviename.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(upcomingMovieActivity, MovieDetailActivity.class);
                intent.putExtra("movieid", movieid);
                upcomingMovieActivity.startActivity(intent);
                Log.d("movieid", String.valueOf(movieid));
            }
        });
        holder.imgnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(upcomingMovieActivity, MovieDetailActivity.class);
                intent.putExtra("movieid",movieid);
                intent.putExtra("moviename",moviename);
                upcomingMovieActivity.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        if(results.size()==0)
        {
            Log.d("222" ,"null results");
            return 1;

        }
        else {
            return results.size();
        }
    }
}
