package com.example.admin.upcoming_movie_app.Controller;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;

import com.example.admin.upcoming_movie_app.ConfigFile.Config;

import com.example.admin.upcoming_movie_app.Model.MovieDetail;
import com.example.admin.upcoming_movie_app.R;
import com.google.gson.Gson;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by Admin on 27-04-2017.
 */
public class DescriptionFragment extends Fragment {
    OkHttpClient okHttpClient = new OkHttpClient();
    private TextView txttittle;
    private TextView txtoverview;
    private RatingBar ratingBar;



    public  DescriptionFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        // Defines the xml file for the fragment




        Bundle bundle = getArguments();
        String movieid =  bundle.getString("id");
        if(movieid==null)
        {
            Log.d("movieid",null);
        }
        else {
            Log.d("Fragment123", movieid);
        }
        String url = Config.moviedetailurl+movieid+Config.api_key;
        Log.d("Fragment", url);
        try {
            MovieDetails(url);
        }catch (IOException e){
            e.printStackTrace();
        }

        return inflater.inflate(R.layout.fragment_moviedetail, parent, false);
    }


    // This event is triggered soon after onCreateView().
    // Any view setup should occur here.  E.g., view lookups and attaching view listeners.
    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        // Setup any handles to view objects here
        // EditText etFoo = (EditText) view.findViewById(R.id.etFoo);
        txttittle = (TextView) view.findViewById(R.id.textView1);
        txtoverview = (TextView) view.findViewById(R.id.textView2);
        ratingBar = (RatingBar) view.findViewById(R.id.ratingBar);
    }



    private void MovieDetails(final String moviedetailurl) throws IOException{
        Request request =new Request.Builder()
                .url(moviedetailurl)
                .build();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d("Fragment","Network Fail");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String jsonData = response.body().string();
                Log.d("errr",jsonData);
                Gson gson = new Gson();
                MovieDetail movieDetail = new MovieDetail();
                movieDetail = gson.fromJson(jsonData,MovieDetail.class);
                Log.d("", movieDetail.getTitle());
                final MovieDetail finalExample = movieDetail;
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        txttittle.setText("" + finalExample.getTitle());
                        txtoverview.setText("Overview:-" + finalExample.getOverview());
                        Double num = finalExample.getPopularity();
                        Log.d("Fragment12", String.valueOf(num));
                        float ratingnumber = (float) (num/20);
                        ratingBar.setStepSize(0.1f);
                        Log.d("Fragment123", String.valueOf(ratingnumber));
                        ratingBar.setRating(Float.parseFloat (String.valueOf(ratingnumber)));

                    }
                });




            }
        });

    }

}
