package com.example.admin.upcoming_movie_app.ViewHolderClass;

import android.media.Image;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.admin.upcoming_movie_app.R;

import org.w3c.dom.Text;

/**
 * Created by Admin on 24-04-2017.
 */
public class RecyclerViewHolder extends RecyclerView.ViewHolder {
   public TextView txtmoviename;
   public TextView txtdate;
   public TextView txtadult;
   public ImageView imgposter;
    public ImageView imgnext;

    public RecyclerViewHolder(View itemView) {
        super(itemView);
        txtmoviename =(TextView) itemView.findViewById(R.id.moviename);
        txtdate = (TextView) itemView.findViewById(R.id.date);
        txtadult = (TextView) itemView.findViewById(R.id.adult);
        imgposter = (ImageView) itemView.findViewById(R.id.imageView);
        imgnext = (ImageView) itemView.findViewById(R.id.imageView1);


    }
}
